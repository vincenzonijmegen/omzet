# ProjectenVincenzo Dashboard

## Overzicht
Dit project bevat een Dash-webapplicatie voor omzetanalyses van de ijssalon.

## Benodigdheden
- Python 3.10+
- Alle packages installeren met:
  ```
  pip install -r requirements.txt
  ```

## Bestandenstructuur
- `dashboard.py` → De Dash webapp
- `sales_data.db` → De omzet database
- `feestdagen 2021-2035.xlsx` → Lijst met feestdagen

## Starten van de app
1. Open een terminal (cmd / PowerShell).
2. Ga naar de dashboardmap:
   ```
   cd C:\Users\van den Akker\ProjectenVincenzo\dashboard
   ```
3. Start de app:
   ```
   python dashboard.py
   ```
4. De app opent automatisch in je browser op `http://127.0.0.1:8050`

## Opmerkingen
- Dit project is bedoeld voor lokaal gebruik.
- Voor productieservers moet een WSGI-server zoals gunicorn worden gebruikt.
